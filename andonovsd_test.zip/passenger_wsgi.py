# Path at remote hosting via cPanel: 
# /home/andonovs/andonovsd_flask/passenger_wsgi.py:
# Path at localPC: C:\Users\Ivan\andonovsd_test\passenger_wsgi.py:
"""
import imp
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

wsgi = imp.load_source('wsgi', 'myapp/app.py') # first argument is a module name
application = wsgi.app #yep
"""

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from importlib.machinery import SourceFileLoader

#mymodule = SourceFileLoader('modname', '/path/to/file.py').load_module()
wsgi = SourceFileLoader('wsgi', 'myapp/app.py').load_module()
application = wsgi.app #yep