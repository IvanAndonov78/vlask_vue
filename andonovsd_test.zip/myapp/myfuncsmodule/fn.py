# Path on remote server (with cPanel):
# /home/andonovs/andonovsd_test/myapp/myfuncsmodule/fn.py
# Path at local PC: C:\Users\Ivan\andonovsd_test\myapp\myfuncsmodule\fn.py

def get_error_page_exiss_msg():
    out = 'This page does not exist'
    return out

    