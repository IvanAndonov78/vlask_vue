# Path at remote hosting via cPanel: 
# /home/andonovs/andonovsd_flask/myapp/app.py:
# Path at localPC: C:\Users\Ivan\andonovsd_test\myapp\app.py:

import os
import sys
import os.path

from myapp.myfuncsmodule import fn

from flask import Flask, request, session, jsonify
#from flask import render_template # Do NOT use render_template IN ORDER to disable Jinja Templates

#app = Flask(__name__)

def create_app():
    #app = Flask(__name__, template_folder = 'C:\\Users\\Ivan\\flask_snippets\\myapp\\templates')
    app = Flask(__name__)
    return app

    
app = create_app()

@app.route('/favicon.ico')
def ignore_favicon():
    return ''


# http://127.0.0.1:5000/
# https://chiponsito.com/
@app.route('/')
def index():
    #return render_template('index.html') 
    # Do NOT use render_template IN ORDER to disable Jinja Templates
    return app.send_static_file('views/index.html')


# http://127.0.0.1:5000/about
# https://chiponsito.com/about
@app.route("/about")
def about():
    return "<p> I am about page </p>"
    
@app.route("/test_errors")
def test_errors():
    # from myapp.myfuncsmodule import fn # yep
    out = fn.get_error_page_exiss_msg()
    return out
    
# http://localhost:5000/test_errors
if __name__ == '__main__':
    #app.run(host='127.0.0.1', debug=True)
    app.run()